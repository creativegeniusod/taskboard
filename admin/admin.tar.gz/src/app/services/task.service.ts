import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { environment } from "../../environments/environment";

const taskUrl: string = environment.production
  ? "http://127.0.0.1:5000/task"
  : "http://127.0.0.1:5000/task";

@Injectable({ providedIn: "root" })
export class TaskService {
  httpOptions = {
    headers: new HttpHeaders({
      "Content-Type": "application/json"
    })
  };

  constructor(private httpClient: HttpClient) {}

  getTasks() {
    return this.httpClient.get(taskUrl, this.httpOptions);
  }

  createTask(body) {
    return this.httpClient.post(taskUrl, body, this.httpOptions);
  }

  getTask(id) {}

  updateTask(id) {}

  deleteTask(id) {
    return this.httpClient.delete(taskUrl + `/${id}`, this.httpOptions);
  }
}
